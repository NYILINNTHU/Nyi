GlobalFood Integration APIs
=====================================

Supported integration APIs:

- Accept Orders API. For documentation go [here](./accepted_orders/README.md).

- Fetch Menu API. For documentation go [here](./fetch_menu/README.md).

- Client Payments API. For documentation go [here](./client_payments/README.md).