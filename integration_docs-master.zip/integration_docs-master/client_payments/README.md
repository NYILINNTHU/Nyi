GlobalFood Client Payments API
=====================================

Work in progress.