[DEPRECATED] GlobalFood Accepted Orders API (Version 1)
=====================================

We offer two main APIs:

1. [Getting an order right after it was accepted by the order taking app](./ORDER.md)

2. [Fetching the restaurants menu](./MENU.md)

NOTE: We no longer update the version 1 documentation. To make use of newer features please upgrade to Version 2. 